import { LightningElement, track, wire, api} from 'lwc';
import fetchWallet from '@salesforce/apex/paypalDataController.fetchWallet';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import SendMoneytoWallet  from '@salesforce/apex/paypalDataController.SendMoneytoWallet';
import fetchAllUsers  from '@salesforce/apex/paypalDataController.fetchAllUsers';
import checkUsers from '@salesforce/apex/paypalDataController.checkUsers';
import LoadWallet from '@salesforce/apex/paypalDataController.LoadWallet';

// import Id from '@salesforce/user/Id';
// import { getRecord } from 'lightning/uiRecordApi';
// import NAME_FIELD from '@salesforce/schema/User.Name';
// import EMAIL_FIELD from '@salesforce/schema/User.Email';

export default class PaypalApp extends LightningElement {


    
////////////////////////////////////////////////////////////////////////

// userId = Id;
// name;
// email;
// error;
// @wire(getRecord, { recordId: Id, fields: [NAME_FIELD, EMAIL_FIELD]}) 
// userDetails({error, data}) {
//     if (data) {
//         this.name = data.fields.Name.value;
//         this.email = data.fields.Email.value;
//     } else if (error) {
//         this.error = error ;
//     }
// }



//USERS DETECT//
@track showAdminView = false;
@track showUserView = false;
handleUser(){
                checkUsers({getProfile: 'System Administrator'}).then(profresult => {
                    if (profresult == true){
                    this.showAdminView = true;
                    this.showUserView = false;
                    }
                });
                checkUsers({getProfile: 'Users Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = false;
                        this.showUserView = true;
                    }
                });
                checkUsers({getProfile: 'Support Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = true;
                        this.showUserView = false;
                    }
                });
         }
/////////////////////////////////////////////////////////////////////////////c/billObject


connectedCallback(){
    this.handleUser();

console.log(this.randomBoolean);
   
            
} 

    // constructor(){
    //     super();
    //     console.log('Record ID' +this.recordId);
    //     console.log('Object :'+ this.objectApiName);
    // }


    
   

    @track walletcolumns = [
    
        {
        label: 'Name',
        fieldName: 'Name',
        },
        {
        label: 'Balance',
        fieldName: 'Balance__c',
        type: 'currency'
        },
        
        ];

        @track wallet2columns = [
    
            {
            label: 'Name',
            fieldName: 'Name',
            },
            {
            label: 'Balance',
            fieldName: 'Balance__c',
            type: 'currency'
            },
            {
                label: 'Added_From__c',
                fieldName: 'UserIdWallet',
               
            },
            {
                label: 'Date Time',
                fieldName: 'Date_Time__c',
               type: 'date'
            },
            
            ];



        @track error;
        @track walletList;
        @wire(fetchWallet)

        wiredwallet(result){
            if(result.data){
                this.walletList = result.data.map(row=>{
                    return {...row, 
                        UserIdWallet: row.Added_From__r.Name}
                })
                this.error = undefined;
            }
            else if(result.error){
                this.error = result.error;
               
            
        }

        }


         @api getaccid;
         @api getaccBalance;
         @api datetime;
         @api getaccName;
         @api getWalletUserid;
        
         @track showSeeBalance = false;
        getSelectedName(event) {
            const selectedRows = event.detail.selectedRows;
            console.log(selectedRows);
             
                 for (let i = 0; i < selectedRows.length; i++){
                // alert("You selected: " + selectedRows[i].Id);
                this.getaccid = selectedRows[i].Id;
                 this.getaccName = selectedRows[i].Name;
                 this.getaccBalance = selectedRows[i].Balance__c;
                 this.datetime = selectedRows[i].Date_Time__c;
                 this.getWalletUserid = selectedRows[i].Added_From__c;
                 console.log(this.getaccid);
                 console.log(this.getaccBalance);
                 console.log(this.getaccName);
                 this.showSeeBalance = true;
                
            }
           
        }

        



    //////////////////////////////////////////////////////////////////
    searchKey;
   @track users;
    //This Funcation will get the value from Text Input.
    handelSearchKey(event){
        this.searchKey = event.target.value;
    }

    //This funcation will fetch the Account Name on basis of searchkey
    SearchAccountHandler(){
        //call Apex method.
        fetchAllUsers({textkey: this.searchKey})
        .then(result => {
                this.users = result;
        })
        .catch( error=>{
            this.users = null;
        });

    }
    cols = [
     
        {label:'User Name', fieldName:'Name' , type:'text'} 
      
              
    ]




    @api sendUser;
    @api sendName;
    handleRowSelection = event => {
        const selectedRows=event.detail.selectedRows;
        
       

        if(selectedRows.length>1)
        {
            var el = this.template.querySelector('.usertbl');
            selectedRows=el.selectedRows=el.selectedRows.slice(1);
            this.showNotification();
            event.preventDefault();
            showToastError() 
             return;
 
            
        }else {
            for (let i = 0; i < selectedRows.length; i++){

                this.sendUser = selectedRows[i].Id;
                
                console.log('Selected Row ID' +this.sendUser  );
              
                //console.log(this.getWalletUserid);
    
            }
        }
       //Detect data of User and Wallet 
}


//Send Money to the Pals

        @track moneytosend;
   

        detectSameInfo() { 
            
            var input = this.template.querySelector(".inputAmount");
           
            this.moneytosend = input.value;
          
            //SendMoneytoWallet({sendmoney:input.value,id:this.sendUser}).then(()=>{
            SendMoneytoWallet({sendmoney:input.value,sender:this.getaccid,id:this.sendUser}).then(()=>{
            const event = new ShowToastEvent({
                title: 'Sent Successfully',
                variant: 'success',
                message:
                    'You have successfully sent a money to your friend. Thank you!',
            });
            this.dispatchEvent(event);
            window.location.reload();
        }).catch(error => {
                
            this.error = error;
            console.log(this.error);
            const event = new ShowToastEvent({
                title: 'Error',
                variant: 'error',
                message:
                    'Please Try Again. Load you wallet before paying sending money',
            });
            this.dispatchEvent(event);
           
    
        });;
    
    //this.showToast();
      
        
             
     }




         //MODAL  SEND MONEY
         @track showEditModal = false;
         openEditModal() {
            this.showEditModal = true;
         }
         closeEditModal() {
            this.showEditModal = false;
         }
         submitEditDetails() {
            
             this.showEditModal = false;
         }
 
         

//  //success transctions
        showToast() {
            const event = new ShowToastEvent({
                title: 'Wow Thank you for Sending Money',
                variant: 'success',
                message:
                    'You have successfully finished this transaction.',
            });
            this.dispatchEvent(event);
            window.location.reload();
        }
        //error
        showToastError() {
            const event = new ShowToastEvent({
                title: 'Please try again',
                variant: 'error',
                message:
                    'Select one row only',
            });
            this.dispatchEvent(event);
        }



  
//Load Wallet

LoadWallet(){
    const random = Math.random() < 0.5;
    console.log(random);
    if (random == true){

        const event = new ShowToastEvent({
            title: 'Infufficient Balance',
            message:
                'You do not have sufficient funds to proceed with this transaction.',
        });
        this.dispatchEvent(event);
       // window.location.reload();
    }else{
        console.log('LOAD NOW');
      // this.openModalForLoadWallet();
        // LoadWallet({money:, id: })

        this.showLoad = true;
    }

}

@track getaccBalances="";
@track getaccName="";

LoadWalletNow(){
    var inputMoney = this.template.querySelector(".balance-inpx");
    this.getaccBalances = inputMoney.value;
    
    LoadWallet({money:inputMoney.value,Id:this.getaccid}).then(()=>{
        const event = new ShowToastEvent({
            title: 'Wow Thank you for Loading your Wallet',
            variant: 'success',
            message:
                'You have successfully finished this transaction.',
        });
        this.dispatchEvent(event);
        window.location.reload();
    }).catch(error => {
            
        this.error = error;
        console.log(this.error);
        const event = new ShowToastEvent({
            title: 'Error',
            variant: 'error',
            message:
                'Please Try again. ',
        });
        this.dispatchEvent(event);
       

    });;
}


    // MODAL FOR load wallet
    @track showLoad = false;
    openModalForLoadWallet() {
     this.showLoad = true;
    }
    closeModalLoad() {
     this.showLoad = false;
    }
    submitDetails() {
       
        this.showLoad = false;
    }



    //MODAL FOR NEW BUTTONS
    @track isModalOpen = false;
    openModal() {
     this.isModalOpen = true;
    }
    closeModal() {
     this.isModalOpen = false;
    }
    closeModal() {
   this.isModalOpen = false;
    }
    submitDetails() {
       
        this.isModalOpen = false;
    }


    showPals = false;
    //Send Money Button
    sendMoney(){
        if(this.showPals)
        {
            this.showPals = false;
        }
        else{
            this.showPals = true;
        }
    }

    


}