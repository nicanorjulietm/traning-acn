import { LightningElement, track, wire, api } from 'lwc';
import fetchAllCards from '@salesforce/apex/paypalDataController.fetchAllCards';
import UserPreferencesReminderSoundOff from '@salesforce/schema/User.UserPreferencesReminderSoundOff';


export default class CardObject extends LightningElement {
    @track cardcolumns =[
    
      
        {
            label: 'User Name',
            fieldName: 'UserName',
           
        },
        {
            label: 'Expire Date',
            fieldName: 'Expired',
           
        },
        {
            label: 'CVV',
            fieldName: 'CVV',
        }

        ,
        {
                label: "Select",
                type: "button",
                typeAttributes: {
                    label: "Select",
                    name: "Select",
                    variant: "brand-outline",
                    
                },
                cellAttributes: { alignment: 'center' }
            }
    ];

        @track cardList;
        @wire(fetchAllCards)
        cards(result){
            if(result.data){
                this.cardList = result.data.map(row=>{
                    return{ 
                        UserName: row.Name__r.Name,
                        Expired: row.Expiry_Date__c,
                        CVV: row.CVV__c
                    }
                })
                this.error = undefined;
            }
            else if(result.error){
                this.error = result.error;
                this.cardList = undefined;
            }
        }


        @api nameofcard;
        @api cvvofcard;
        @api expiredcard;

        handleRowAction(event){
            if(event.detail.action.name === "Select"){
            // this.recordBillId = event.detail.row.Id  ;
           console.log(event.detail.row.UserName);
           console.log(event.detail.row.CVV);
           console.log(event.detail.row.Expired);
      
           this.nameofcard = event.detail.row.UserName;
           this.cvvofcard = event.detail.row.CVV;
           this.expiredcard = event.detail.row.Expired;
            
            }
        }
    








        //MODAL FOR NEW BUTTONS
        @track isModalOpen = false;
        openModal() {
        this.isModalOpen = true;
        }
        closeModal() {
        this.isModalOpen = false;
        }
        closeModal() {
        this.isModalOpen = false;
        }
        submitDetails() {
        this.isModalOpen = false;
        }



}