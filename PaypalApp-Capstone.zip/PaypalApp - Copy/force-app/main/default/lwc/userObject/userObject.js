import { LightningElement, track, wire, api } from 'lwc';
import checkUsers from '@salesforce/apex/paypalDataController.checkUsers';
import createUser from '@salesforce/apex/paypalDataController.createUser';
import fetchUsers from '@salesforce/apex/paypalDataController.fetchUsers';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import EditUserDetails from '@salesforce/apex/paypalDataController.EditUserDetails';
import TickerSymbol from '@salesforce/schema/Account.TickerSymbol';
import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi';
import NAME_FIELD from '@salesforce/schema/User.Name';
import EMAIL_FIELD from '@salesforce/schema/User.Email';
const usercolumns =[
    
    {
    label: 'Name',
    fieldName: 'Name',
    type: 'text'
    },
    {
        label: 'Email',
        fieldName: 'Email__c',
        type: 'email'
    },
    {
        label: 'Phone',
        fieldName: 'Mobile_Number__c',
        type:'Phone'
    },
    
    {
        label: 'Flag Result',
        fieldName: 'Flag__c',
       
    },
    {
            label: "Edit Details",
            type: "button",
            typeAttributes: {
                label: "Edit Details",
                name: "Edit Details",
                variant: "brand-outline",
                
            },
            cellAttributes: { alignment: 'center' }
        }
        
    

];

export default class UserObject extends LightningElement {
    //Get Current User Record 
    userId = Id;
    name;
    email;
    error;
    @wire(getRecord, { recordId: Id, fields: [NAME_FIELD, EMAIL_FIELD]}) 
    userDetails({error, data}) {
        if (data) {
            this.name = data.fields.Name.value;
            this.email = data.fields.Email.value;
        } else if (error) {
            this.error = error ;
        }
    }

    userColumsList = usercolumns; 
    
    @wire(fetchUsers)
    usersList;
    connectedCallback(){
      
        this.handleUser();
    }
    


    
    @api inpEmails = "";
    @api inpPhones ;
    @api inpFlags;
    @api inpNames = "";
    @api rowId;
   
    handleRowAction(event){
        if(event.detail.action.name === "Edit Details"){
            this.inpNames = event.detail.row.Name;
            this.inpEmails = event.detail.row.Email__c;
            this.inpFlag =event.detail.row.Flag__c;
            this.inpPhones = event.detail.row.Mobile_Number__c;
            this.rowId = event.detail.row.Id;
           
        }

    
    }



    @track inpName ="";
    @track inpEmail ="";
    @track inpPhone;
    @track inpFlagsx;
handleSaveEdit() {

    const inpName = this.template.querySelector(".name-inps");
    const inpEmail = this.template.querySelector(".email-inps");
    const inpPhone = this.template.querySelector(".phone-inps");
    const inpFlagsx = this.template.querySelector(".flag-inps");
    this.inpEmail = inpEmail.value;
    this.inpName = inpName.value;
    this.inpPhone = inpPhone.value;
    this.inpFlagsx = inpFlagsx.value;
    console.log(inpEmail.value);
    console.log(inpName.value);
    console.log(inpFlagsx.checked);
    console.log(inpPhone.value);
    console.log(this.rowId);
   
    EditUserDetails({flag:inpFlagsx.checked, Email:inpEmail.value, Mobile:inpPhone.value,userName:inpName.value,Id:this.rowId  })
    this.showToastSuccessfulEdit();
   
       
}

showToastSuccessfulEdit() {
    const event = new ShowToastEvent({
        title: 'Edit Successfully',
        variant: 'success',
        message:
            'You have successfully edit the account. Please check again',
    });
    this.dispatchEvent(event);
    window.location.reload();
}







////////////////////////////////////////////////////////////////////////
//USERS DETECT//
@track showAdminView = false;
@track showUserView = false;
handleUser(){
                checkUsers({getProfile: 'System Administrator'}).then(profresult => {
                    if (profresult == true){
                    this.showAdminView = true;
                    this.showUserView = false;
                    }
                });
                checkUsers({getProfile: 'Users Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = false;
                        this.showUserView = true;
                    }
                });
                checkUsers({getProfile: 'Support Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = true;
                        this.showUserView = false;
                    }
                });
         }
/////////////////////////////////////////////////////////////////////////////c/billObject

         
         @track inpPhone;

    handleSignUp(event){
        try{
            const inpName = this.template.querySelector(".name-inp");
            const inpEmail = this.template.querySelector(".email-inp");
            const inpPhone = this.template.querySelector(".phone-inp");
            this.email = inpEmail.value;
            this.name = inpName.value;
            this.inpPhone = inpPhone.value;
            console.log(inpName.value);
            console.log(inpEmail.value);
            console.log(inpPhone.value);
            console.log(this.userId);
          
            createUser({userName:inpName.value, userEmail:inpEmail.value, userPhone:inpPhone.value});
            this.showToast();
        } catch(error){
            this.showToastErrors();
        }
       
    }
    showToast() {
        const event = new ShowToastEvent({
            title: 'Thank you for Signing up',
            variant: 'success',
            message:
                'You have successfully created your account.',
        });
        this.dispatchEvent(event);
       window.location.reload();
    }

    showToastErrors() {
        const event = new ShowToastEvent({
            title: 'Please try again',
            variant: 'error',        
        });
        this.dispatchEvent(event);
       window.location.reload();
    }

  //MODAL FOR NEW BUTTONS
  @track isModalOpen = false;
  openModal() {
   this.isModalOpen = true;
  }
  closeModal() {
   this.isModalOpen = false;
  }
  closeModal() {
 this.isModalOpen = false;
  }
  submitDetails() {
  this.isModalOpen = false;
  }


    //MODAL FOR NEW BUTTONS
    @track showEditModal = false;
    openEditModal() {
     this.showEditModal = true;
    }
    closeEditModal() {
     this.showEditModal = false;
    }
    closeEditModal() {
   this.showEditModal = false;
    }
    submitEditDetails() {
    this.showEditModal = false;
    this.handleSaveEdit();
    }
  
}