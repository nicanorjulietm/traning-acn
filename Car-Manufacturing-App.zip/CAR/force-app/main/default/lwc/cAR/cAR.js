import { LightningElement, api, track, wire } from 'lwc';
import checkUsers from '@salesforce/apex/checkWho.checkUsers';
import getCarModel from '@salesforce/apex/DataCarController.fetchCarModel';
import getCarBooking from '@salesforce/apex/DataCarController.fetchCarBooking';
import fetchCar from '@salesforce/apex/DataCarController.fetchCar';
import getAccount from '@salesforce/apex/DataCarController.fetchAccounts';
import getLead from '@salesforce/apex/DataCarController.fetchLead';
import getContact from '@salesforce/apex/DataCarController.fetchContact';
import getopportunity from '@salesforce/apex/DataCarController.fetchOpportunity';
import getCampaigns from '@salesforce/apex/DataCarController.fetchCampaign';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';


const colForCar = [
    {
    label: 'Car Name',
    fieldName: 'Name', 
    type: 'text',
    editable: true
    }
];

const colForCarModel = [
    {
    label: 'Name',
    fieldName: 'Name', 
    type: 'text',
    editable: true
    },
    {
        label: 'Stage',
        fieldName: 'Stages__c',
        type:'picklist',
        editable: true
    },
    {
        label: "View",
        type: "button",
        typeAttributes: {
            label: "View",
            name: "View",
            variant: "brand-outline",
            
        },
        cellAttributes: { alignment: 'center' }
    }
  
];

const colForCarBooking = [
    {
    label: 'Car Booking No',
    fieldName: 'Name', 
    type: 'autonumber'
    }
  
];


const leads = [
    {
        label:'Name',
        fieldName:'Name',
        type: 'text'
    },
    {
        label: 'Status',
        fieldName: 'Status',
        type: 'picklist'
    }
];

const campaigns = [
    {
        label:'Name',
        fieldName:'Name',
        type: 'text'
    },
    {
        label: 'Status',
        fieldName: 'Status',
        type: 'picklist'
    },
    {
        label: 'Type',
        fieldName: 'Type',
        type: 'picklist'
    }
];

const accounts = [
    {
        label:'Name',
        fieldName:'RecordDetail',
        type: 'url',
        typeAttributes:{
            //what fieldname
            label: {
                fieldName: 'Name'
            }
        }
    },
    {
        label: 'Phone',
        fieldName: 'Phone',
        type: 'phone'
    }, 
    {
        label: 'AR',
        fieldName: 'AnnualRevenue',
        type: 'currency'
    }
];

const contacts = [
    {
        label:'Name',
        fieldName:'ContactUrl',
        type: 'url',
        typeAttributes:{
            //what fieldname
            label: {
                fieldName: 'Name'
            }
          
        }
    }, 
    {
        label:'AccountName',
        fieldName:'RecordDetail',
        type: 'url',
        typeAttributes:{
            //what fieldname
            label: {
                fieldName: 'AccountName'
            }
          
        }
    },
    {
        label: 'Phone',
        fieldName: 'Phone',
        type: 'phone'
    },
    {
        label: 'Email',
        fieldName: 'Email',
        type: 'email'
    }
];



const opportunities = [
    {
        label:'Name',
        fieldName:'OpportunityUrl',
        type: 'url',
        typeAttributes:{
            //what fieldname
            label: {
                fieldName: 'Name'
            }
          
        }
    }, 
    {
        label:'AccountName',
        fieldName:'RecordDetail',
        type: 'url',
        typeAttributes:{
            //what fieldname
            label: {
                fieldName: 'AccountName'
            }
          
        }
    },
    {
        label: 'Stages',
        fieldName: 'StageName',
        type: 'picklist'
    }

];
export default class CAR extends LightningElement {

// GET CAR MODEL DATA
carcolumns = colForCar;
@track carRecords;
saveDraftValues = [];
@wire(fetchCar)
carData(results) {
    this.carRecords = results;
    console.log(results);
    if (results.error) {
        this.carRecords= undefined;
        console.log("the fuck" +error)
    }
};

// handleSave(event) {
//     this.saveDraftValues = event.detail.draftValues;
//     const recordInputs = this.saveDraftValues.slice().map(draft => {
//         const fields = Object.assign({}, draft);
//         return { fields };
//     });

//     // Updateing the records using the UiRecordAPi
//     const promises = recordInputs.map(recordInput => updateRecord(recordInput));
//     Promise.all(promises).then(res => {
//         this.ShowToast('Success', 'Records Updated Successfully!', 'success', 'dismissable');
//         this.saveDraftValues = [];
//         return this.refresh();
//     }).catch(error => {
//         this.ShowToast('Error', 'An Error Occured!!', 'error', 'dismissable');
//     }).finally(() => {
//         this.saveDraftValues = [];
//     });
// }

// ShowToast(title, message, variant, mode){
//     const evt = new ShowToastEvent({
//             title: title,
//             message:message,
//             variant: variant,
//             mode: mode
//         });
//         this.dispatchEvent(evt);
// }

// This function is used to refresh the table once data updated
async refresh() {
    await refreshApex(this.carRecords);
}
// GET CAR MODEL DATA
carmodelcolumns = colForCarModel;
@wire(getCarModel)
carmodelRecords; 
// GET CAR booking DATA
carbookingcolumns = colForCarBooking;
@wire(getCarBooking)
carbookingRecords;

//GET LEAD
leadscolumns = leads;
@wire(getLead)
leadRecords;

//GET Campaign
campaigncolumns = campaigns;
@wire(getCampaigns)
CampaignRecords;


//GET ACCOUNTS 
accountscolumns = accounts;


//GET Contract
contactcolumns = contacts;


opportunitiescolumns = opportunities;
result;
error;
oppResult;
handleAccountData() 
{

    getAccount().then( res => {
        //this.result = res;
        if(res){
            let finahlChange = [];
            res.forEach(row => {
                let objectStructure = {};
                objectStructure.Id = row.Id;
                objectStructure.Name = row.Name;
                objectStructure.Phone = row.Phone;
                objectStructure.AnnualRevenue = row.AnnualRevenue;
                //url
                objectStructure.RecordDetail = 'https://brave-moose-dnjg6w-dev-ed.lightning.force.com/lightning/r/Account/' +row.Id+ '/view'
           finahlChange.push(objectStructure);
            });
            //update the result
            this.result= finahlChange;
        }
    }).catch(err =>{
        this.error = err;
    })

  //  For Contact
    getContact().then( res => {
        //  this.conResult = res;
                if(res){
                    let finahlChange = [];
                    res.forEach(row => {
                        let objectStructure = {};
                        objectStructure.Id = row.Ids;
                        objectStructure.Name = row.Name;
                        objectStructure.Phone = row.Phone;
                        objectStructure.Email = row.Email;
                        objectStructure.AccountName = row.Account.Name;
                        //url
                        objectStructure.RecordDetail = 'https://cmcstudy-dev-ed.lightning.force.com//lightning/r/Account/' +row.Id+ '/view';
                        objectStructure.ContactUrl =  objectStructure.RecordDetail = 'https://cmcstudy-dev-ed.lightning.force.com//lightning/r/Contact/'+row.AccountId+'/view';
                        finahlChange.push(objectStructure);
                    });
                    //update the result
                    this.conResult= finahlChange;
                }

        }).catch(err =>{
            this.conError = err;
        });

 //For Opportunity
 getopportunity().then( res => {
    //  this.conResult = res;
            if(res){
                let finahlChange = [];
                res.forEach(row => {
                    let objectStructure = {};
                    objectStructure.Id = row.Ids;
                    objectStructure.Name = row.Name;
                    objectStructure.AccountName = row.Account.Name;
                    objectStructure.StageName= row.StageName;
                    //url
                    objectStructure.RecordDetail = 'https://cmcstudy-dev-ed.lightning.force.com/lightning/r/Account/' +row.Id+ '/view';
                    objectStructure.OpportunityUrl =  objectStructure.RecordDetail = 'https://cmcstudy-dev-ed.lightning.force.com//lightning/r/Contact/'+row.AccountId+'/view';
                    finahlChange.push(objectStructure);
                });
                //update the result
                this.oppResult= finahlChange;
            }

        }).catch(err =>{
        this.conError = err;
        });

}




@track showAccount = false;
@track showLead = false;
@track showContacts = false;
@track showOpportunity = false;
@track showCar = false;
@track showCarModel = false;
@track showCarBookng = false;
@track showCampaign = false;


handleUser(){

    checkUsers({getProfile: 'Company Executives'}).then(profresult => {
        if (profresult == true){
            this.showAccount = true;
            this.showLead = true;
            this.showContacts =true;
            this.showOpportunity =true;
            this.showCar = true;
            this.showCarModel = true;
            this.showCarBookng = true;

        }
    });

    checkUsers({getProfile: 'Factory Executives'}).then(profresult => {
        if (profresult == true){
            this.showCar =true;
            this.showCarModel =true;
            
            
        }
    });

    checkUsers({getProfile: 'System Administrator'}).then(profresult => {
        if (profresult == true){
            this.showAccount = true;
            this.showLead = true;
            this.showContacts =true;
            this.showOpportunity =true;
            this.showCar = true;
            this.showCarModel = true;
            this.showCarBookng = true;
           
        }
    });

    checkUsers({getProfile: 'Quality Analysts'}).then(profresult => {
        if (profresult == true){
            this.showCarModel = true;
        }
    });
    checkUsers({getProfile: 'Digital Marketer'}).then(profresult => {
        if(profresult == true){
            this.showCarModel = true;
            this.showAccount = true; 
            this.showContacts = true;
            this.showCampaign = true;
        }
    });
    checkUsers({getProfile: 'Sales Executives'}).then(profresult => {
        if(profresult == true){
            this.showCarModel = true;
            this.showAccount = true; 
            
        }
    });
}



  
//MODAL FOR NEW BUTTONS
    @track isModalOpen = false;
    openModal() {
     this.isModalOpen = true;
    }
    closeModal() {
     this.isModalOpen = false;
    }
    closeModal() {
   this.isModalOpen = false;
    }
    submitDetails() {
  
        this.isModalOpen = false;
    }


  getaccId;
    getSelectedName(event) {
        const selectedRows = event.detail.selectedRows;
             for (let i = 0; i < selectedRows.length; i++){
            // alert("You selected: " + selectedRows[i].Id);
             this.getaccId = selectedRows[i].Id;
             console.log(this.getaccId);
        }
       
    }

    showAcc = false;
    handleClickId(){
        if(this.showAcc){
            this.showAcc = false;
        }else{
            this.showAcc =true;
        }
    }
    



//#############################################################################

connectedCallback(){
    this.handleAccountData();
    this.handleUser();
}


//#############################################################################





}