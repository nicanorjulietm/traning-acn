import { LightningElement, track, api, wire } from 'lwc';
import fetchCar from '@salesforce/apex/DataCarController.fetchCar';
import EditCar from '@salesforce/apex/DataCarController.EditCar';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class CarObject extends LightningElement {
    
  @track colForCar = [
        {
        label: 'Car Name',
        fieldName: 'Name', 
       type: 'text'
        },
        {
            label: 'Car Price',
            fieldName: 'Car_Price__c',
            type: 'currency'
        },
        {
                label: "Edit",
                type: "button",
                typeAttributes: {
                    label: "Edit",
                    name: "Edit",
                    variant: "brand-outline",
                    
                },
                cellAttributes: { alignment: 'center' }
            }
    ];




    @track carList;
    @wire(fetchCar)
    carsdata(result){
        if(result.data){
            this.carList = result.data.map(row=>{
                return {...row, 
            
                    }
            })
            this.error = undefined;
        }
        else if(result.error){
            this.error = result.error;
            this.carList = undefined;
        }
    }


    @api carName = "";
    @api carPrice = "";
    @api carRowId;
        // Handle OnrowAction of Edit
        handleRowAction(event){
            if(event.detail.action.name === "Edit"){
            this.carName = event.detail.row.Name;
            this.carPrice = event.detail.row.Car_Price__c
            this.carRowId = event.detail.row.Id;
            console.log(event.detail.row.Id);

            }
        }


        @track carName;
        @track carPrice;

        //Handle Save Button for Edit
        handleSave(){
            
            var inputName = this.template.querySelector(".carname");
            var inputPrice = this.template.querySelector(".carprice");
            this.carName = inputName.value;
            this.carPrice = inputPrice.value;
        
           EditCar({carNames:inputName.value,carPrices:inputPrice.value, Id:this.carRowId});
            this.showToastSuccess();
            console.log(this.carRowId);
        }

    //Toast for Success Edit
    showToastSuccess(){      
        const event = new ShowToastEvent({
            title: 'Succesfully Done!',
            variant: 'Success',
           
        });
        this.dispatchEvent(event);
        window.location.reload();
      
}




            //MODAL FOR NEW BUTTONS
            @track isModalOpen = false;
            openModal() {
            this.isModalOpen = true;
            }
            closeModal() {
            this.isModalOpen = false;
            }
            closeModal() {
            this.isModalOpen = false;
            }
            submitDetails() {
            this.isModalOpen = false;
            }



}