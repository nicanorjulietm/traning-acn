import { LightningElement, track, wire, api } from 'lwc';
import getCarModel from '@salesforce/apex/DataCarController.fetchCarModel';
import EditCarModel from '@salesforce/apex/DataCarController.EditCarModel';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import checkUsers from '@salesforce/apex/checkWho.checkUsers';
export default class CarModelObject extends LightningElement {

    @track colForCarModel = [
        {
        label: 'Name',
        fieldName: 'carName', 
        type: 'text',
      
        },
        {
            label: 'Price',
            fieldName: 'carPrice',
           
        },
        
        {
            label: 'Stage',
            fieldName: 'Stages__c',
            type:'picklist',
            
        },
        {
            label: "View",
            type: "button",
            typeAttributes: {
                label: "View",
                name: "View",
                variant: "brand-outline",
                
            },
            cellAttributes: { alignment: 'center' }
        }
      
    ];


    
    @track carModelList;
    @wire(getCarModel)
    carsdata(result){
        if(result.data){
            this.carModelList = result.data.map(row=>{
                return {...row, 
                    carName: row.Car__r.Name,
                    carPrice: row.Car__r.Car_Price__c,
                    carUrl: row.Image_URL__c,
                    carColor: row.Color__c,
                    carSeating: row.Seating__c,
                    carEngineType: row.Engine_Type__c

                    }
            })
            this.error = undefined;
        }
        else if(result.error){
            this.error = result.error;
            this.carLcarModelListist = undefined;
        }
    }

    @api imageUrl;
    @api carName;
    @api carPrice ="";
    @api carseat ="";
    @api carColor ="";
    @api carEngine ="" ;
    handleRowAction(event){
        if(event.detail.action.name === "View"){
            
            this.carName = event.detail.row.carName;
            this.carPrice = event.detail.row.carPrice
            this.carRowId = event.detail.row.Id;
            this.carColor = event.detail.row.Color__c;
            this.carseat = event.detail.row.Seating__c;
            this.carEngine = event.detail.row.Engine_Type__c;
            this.imageUrl = event.detail.row.carUrl;
            this.carID=event.detail.row.Id;
            console.log(event.detail.row.Id);
            console.log(event.detail.row.carColor);
            console.log(event.detail.row.carSeating);
            console.log(event.detail.row.carEngineType);

        }
    }
    @track carID;
    @track imageUrl;
    @track carName;
    @track carPrice;
    @track carseat;
    @track carColor;
    @track carEngine;


        //Handle Save Button for Edit
        handleEdit(){
            
            var inputName = this.template.querySelector(".carname");
            var inputPrice = this.template.querySelector(".carprice");
            var inputColor = this.template.querySelector(".carColor");
            var inputSeating = this.template.querySelector(".carseat");
            var inputEnginine = this.template.querySelector(".carEngine");
            this.carName = inputName.value;
            this.carPrice = inputPrice.value;
            this.carColor = inputColor.value;
            this.carseat = inputSeating.value;
            this.carEngine = inputEnginine.value;
        
             EditCarModel({carnames:inputName.value,carPrices:inputPrice.value,Id:this.carID,color:inputColor.value,engine:inputEnginine.value,seat:inputSeating.value});
           
             this.showToastSuccess();
            
        }
   //Toast for Success Edit
        showToastSuccess(){      
            const event = new ShowToastEvent({
                title: 'Succesfully Done!',
                variant: 'Success',
            
            });
            this.dispatchEvent(event);
            window.location.reload();
        }

            //MODAL FOR NEW BUTTONS
            @track isModalOpen = false;
            openModal() {
            this.isModalOpen = true;
            }
            closeModal() {
            this.isModalOpen = false;
            }
            closeModal() {
            this.isModalOpen = false;
            }
            submitDetails() {
            this.isModalOpen = false;
            }



            

            showAddFeatures = false;
            showBuyBtn = false;
 //////////////////////////////////////////////////////////////////////////////////
            connectedCallback(){
                this.handleUser();

          
            
            }

            handleUser(){

                checkUsers({getProfile: 'Company Executives'}).then(profresult => {
                    if (profresult == true){
                     
            
                    }
                });
            
                checkUsers({getProfile: 'Factory Executives'}).then(profresult => {
                    if (profresult == true){
                       
                        
                    }
                });
            
                checkUsers({getProfile: 'System Administrator'}).then(profresult => {
                    if (profresult == true){
                       this.showAddFeatures = true;
                       this.showBuyBtn = false;
                       
                    }
                });
            
                checkUsers({getProfile: 'Quality Analysts'}).then(profresult => {
                    if (profresult == true){
                        
                    }
                });
                checkUsers({getProfile: 'Digital Marketer'}).then(profresult => {
                    if(profresult == true){
                       
                    }
                });
                checkUsers({getProfile: 'Sales Executives'}).then(profresult => {
                    if(profresult == true){
                       
                        
                    }
                });
                checkUsers({getProfile: 'Customer'}).then(profresult => {
                    if(profresult == true){
                       this.showAddFeatures = false;
                       this.showBuyBtn = true;
                        
                    }
                });
            }
            
            
/////////////////////////////////////////////////////////////////////////////////





}