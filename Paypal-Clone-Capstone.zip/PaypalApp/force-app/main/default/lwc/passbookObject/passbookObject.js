import { LightningElement, track, api, wire } from 'lwc';
import fetchAllPassbooks from '@salesforce/apex/paypalDataController.fetchAllPassbooks';
import PdfLib from '@salesforce/resourceUrl/PdfLib';
import {loadScript} from 'lightning/platformResourceLoader';
import checkUsers from '@salesforce/apex/paypalDataController.checkUsers';


import UserPreferencesRecordHomeReservedWTShown from '@salesforce/schema/User.UserPreferencesRecordHomeReservedWTShown';
//import CallCenter from '@salesforce/schema/User.CallCenter';
export default class PassbookObject extends LightningElement {
    @track passbookcolumns = [
        {
            label: 'User ID',
            fieldName: 'User__c'
        },
        {
            label: 'User',
            fieldName: 'PassbookUserName',
            type: 'text'
        },
        
        {
            label: 'Email',
            fieldName: 'Email',
            type: 'email'
        },
        {
            label: 'Vendor Name',
            fieldName: 'Name',
            type: 'text'
        },
        {
            label: 'Amount',
            fieldName: 'Amount__c',
            type: 'currency'
        },
        {
                label: "View Details",
                type: "button",
                typeAttributes: {
                    label: "View Details",
                    name: "ViewDetails",
                    variant: "brand-outline",
                    
                },
                cellAttributes: { alignment: 'center' }
            }
    ];


@track passbookList;
@wire(fetchAllPassbooks)
passbooks(result){
    if(result.data){
        this.passbookList = result.data.map(row =>{
            return{...row, 
            PassbookUserName: row.User__r.Name,
            Email: row.User__r.Email__c
            }
        })
        this.error = undefined;
    }
    else if(result.error){
        this.error = result.error;
        this.passbookList = undefined;
    }
}


        @api recordPayId;
        @api recordPayName;
        @api recordUserName;
        @api recordPayAmount;
        @api recordPayEmail;
        handleRowAction(event){
            if(event.detail.action.name === "ViewDetails"){
                
                this.recordPayId = event.detail.row.Id;
                this.recordPayName = event.detail.row.Name;
                this.recordUserName = event.detail.row.PassbookUserName;
                this.recordPayAmount = event.detail.row.Amount__c;
                this.recordPayEmail = event.detail.row.Email;
            }
        }




          //MODAL FOR Create NEW BUTTONS
    @track isModalOpen = false;
    openModal() { this.isModalOpen = true; }
    closeModal() { this.isModalOpen = false; }
     submitDetails() { this.isModalOpen = false; }


    ////////////////////////////c/

    renderedCallback(){
        loadScript(this, PdfLib).then(() =>{

        });
    }

    async createPdf() {
        const pdfDoc = await PDFLib.PDFDocument.create()
        const timesRomanFont = await pdfDoc.embedFont(
            PDFLib.StandardFonts.TimesRoman)
      
        const page = pdfDoc.addPage()
        const { width, height } = page.getSize()
        const fontSize = 30
        page.drawText('Paybook Transactions' , {
            x: 50,
            y: height - 4 * fontSize,
            size: 18,
            alignment: CallCenter,
           
            font: timesRomanFont,
          
          })
        page.drawText('\n \n User : '+this.recordUserName+' \n Email : ' +this.recordPayEmail +'\n Vendor Name : ' +this.recordPayName+ '\n Amount : '+this.recordPayAmount+'\n' , {
          x: 50,
          y: height - 4 * fontSize,
          size: 12,
         
          font: timesRomanFont,
         
        })
        
      
        const pdfBytes = await pdfDoc.save()
        this.saveByteArray("My PDF", pdfBytes );
      }
      saveByteArray(pdfName, byte){
        var blob = new Blob([byte], {type: "application/pdf"});
        var link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        var fileName = pdfName;
        link.download = fileName;
        link.click();
      }


////////////////////////////////////////////////////////////////////////
@track showAdminView = false;
@track showUserView = false;
handleUser(){
                checkUsers({getProfile: 'System Administrator'}).then(profresult => {
                    if (profresult == true){
                    this.showAdminView = true;
                    this.showUserView = false;
                    }
                });
                checkUsers({getProfile: 'Users Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = false;
                        this.showUserView = true;
                    }
                });
                checkUsers({getProfile: 'Support Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = true;
                        this.showUserView = false;
                    }
                });
         }
/////////////////////////////////////////////////////////////////////////////c/billObject

connectedCallback(){
    this.handleUser();
}

}

