import { LightningElement, track, wire, api } from 'lwc';
//import fetchAccounts from '@salesforce/apex/DataExample.fetchAccounts';
import fetchBill from '@salesforce/apex/paypalDataController.fetchBill';
import fetchSingleWallet from '@salesforce/apex/paypalDataController.fetchSingleWallet';
import fetchWallet from '@salesforce/apex/paypalDataController.fetchWallet';
//import SavetoPassBook from '@salesforce/apex/paypalDataController.SavetoPassBook';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import checkUsers from '@salesforce/apex/paypalDataController.checkUsers';
import UserPreferencesReminderSoundOff from '@salesforce/schema/User.UserPreferencesReminderSoundOff';
import AssigntoBillOwner from '@salesforce/apex/paypalDataController.AssigntoBillOwner';
import AssignBill from '@salesforce/apex/paypalDataController.AssignBill';

export default class BillObject extends NavigationMixin (LightningElement) {
    @track billcolumns = [
        {
        label: 'User ID',
        fieldName: 'For_User__c',
    
        }
        ,
        {
        label: 'For User',
        fieldName: 'ForUser',
        type: 'text'
        } ,
      
        {
            label: 'Amount',
            fieldName: 'Amount__c',
            type: 'currency'
        },
        {
            label: 'Applied Discount',
            fieldName: 'Offer_Applied__c',
           
        },
        
        {
            label: 'Paid',
            fieldName: 'Paid__c',
           
        },
        
        {
            label: 'Flag Result',
            fieldName: 'Flag__c'
           
        },
        {
            label: 'Cancel',
            fieldName: 'Cancel__c'
           
        },
        {
                label: "View",
                type: "button",
                typeAttributes: {
                    label: "View",
                    name: "PayBills",
                    variant: "brand-outline",
                    
                },
                cellAttributes: { alignment: 'center' }
            }
        
        ];

       
  // TRACK DETAILS
        @track billsList;
        @wire(fetchBill)
        bills(result){
            if(result.data){
                this.billsList = result.data.map(row=>{
                    return {...row, 
                        ForUser: row.For_User__r.Name,
                        OwnerId: row.For_User__r.OwnerId,
                        assigned: row.AssignedToUser__c
                       
                        }
                })
                this.error = undefined;
            }
            else if(result.error){
                this.error = result.error;
                this.billsList = undefined;
            }
        }

  
        //Get Wallet Record
        @track error;
        @track walletList;
        @wire(fetchWallet)

        wiredwallet(result){
            if(result.data){
                this.walletList = result.data.map(row=>{
                    return {...row, 
                        UserIdWallet: row.Added_From__r.Name,
                        walletBalance: row.Balance__c
                    }
                })
                this.error = undefined;
            }
            else if(result.error){
                this.error = result.error;
            
            
            }

        }



//BILLS INFORMATION PAYMENT
        @api recordBillId;
        @api recordBillName;
        @api amountoPay;
        @api recordBillDiscount;
        @api recordUserId;
        @api recordFOrUSerId
        @api rowId;
        showBtn = true;
        showBtnPaid= false;
        showBtnAssigned = true;
  //HANDLE PAYMENT      
    handleRowAction(event){
        if(event.detail.action.name === "PayBills"){
        // this.recordBillId = event.detail.row.Id  ;
        this.recordUserId = event.detail.row.For_User__c;
         this.recordBillName = event.detail.row.ForUser ; 
         this.amountoPay = event.detail.row.Amount__c;
         this.recordBillDiscount =event.detail.row.Offer_Applied__c;
        this.recordFOrUSerId = event.detail.row.OwnerId;
       this.rowId = event.detail.row.Id;
  
      
        
         event.detail.row.Paid__c;
         event.detail.row.Flag__c;
     
        if(event.detail.row.Paid__c === true){
            this.showBtn = false;
            this.showBtnPaid = true;
        /// INFO, ALREADY PAID
            const event = new ShowToastEvent({
                title: 'Already Paid',
                variant: 'info',
                message:
                    'Bill has already been paid by the user.',
            });
            this.dispatchEvent(event);


        }else if(event.detail.row.Flag__c === true){
            this.showBtn = false;
            this.showBtnPaid = false;
            
           
            /// ERROR PAYING ACCOUNT HAS BEEN FLAG
            const event = new ShowToastEvent({
                title: 'Error Paying the Bills',
                variant: 'error',
                message:
                    'Your account is being restricted at this moment please contact the administration to fix it.',
            });
            this.dispatchEvent(event);

           
        }else if(event.detail.row.Cancel__c === true) {
        
            console.log(event.detail.row.Cancel__c);
       
            
            this.showBtn = false;
        this.showCancel();
        }
        else {
            this.showBtn = true;
            this.showBtnPaid = false;

        }
                   
        
        }
    }
 /// ERROR PAYING ACCOUNT HAS BEEN CANCELED
    showCancel(){
        const event = new ShowToastEvent({
                title: 'Error',
                variant: 'error',
                message:
                    'Bill has been canceled by administrator. Please contact the administration to fix it.',
            });
            this.dispatchEvent(event);
    }
   
       
        

        @api getaccBalance;
        @track payment;
        @track amountoPay;

        //for Payment
        handlePay(){
            console.log('Row Id is '+this.rowId);
       
            var inp = this.template.querySelector("lightning-input");
            this.amountoPay  = inp.value;
            console.log(this.amountoPay);
            console.log(inp.value);
            console.log(this.recordBillName);
            fetchSingleWallet({payment: inp.value, id:this.recordUserId, nameofuser:this.recordBillName, BillID:this.rowId}).then(()=>{
                const event = new ShowToastEvent({
                    title: 'Thank you for Paying your Bill',
                    variant: 'success',
                    message:
                        'You have successfully paid your bill. Please check your balance',
                });
                this.dispatchEvent(event);
                window.location.reload();



            }).catch(error => {
                
                this.error = error;
                console.log(this.error);

             


                const event = new ShowToastEvent({
                    title: 'Error',
                    variant: 'error',
                    message:
                        'Please Try again. Your wallet is less than the amount of the Bill.',

                });
                this.dispatchEvent(event);
               
        
                    // Navigate to a URL
                    this[NavigationMixin.Navigate]({
                        type: 'standard__webPage',
                        attributes: {
                            url: 'https://paypalapp-dev-ed.lightning.force.com/lightning/n/Wallet'
                        }
                    },
                    true // Replaces the current page in your browser history with the URL
                  );
                

         });;
            console.log(this.recordUserId);
           // this.handleAddtoPassBook()
          // SavetoPassBook({payment: inp.value, id:this.recordUserId, nameofuser:this.recordBillName});
            //this.showToast();
            
       
          
    }



    //MODAL FOR NEW BUTTONS
    @track isModalOpen = false;
    openModal() {
     this.isModalOpen = true;
    }
    closeModal() {
     this.isModalOpen = false;
    }
    closeModal() {
   this.isModalOpen = false;
    }
    submitDetails() {
    this.isModalOpen = false;
    }


    handleCancel(){
       console.log(this.rowId);
      AssigntoBillOwner({Id:this.rowId}).then(()=>{
        const event = new ShowToastEvent({
            title: 'Successfully Cancel',
            variant: 'success',
            
        });
        this.dispatchEvent(event);
        window.location.reload();


    }).catch(error => {
        
        this.error = error;
        console.log(this.error);
        const event = new ShowToastEvent({
            title: 'Error',
            variant: 'error',
            message:
                'Please Try again. Canceling Bill Error',
        });
        this.dispatchEvent(event);
       

    });;
      
    }

    // showToastAssign() {
    //         const event = new ShowToastEvent({
    //             title: 'Assigned',
    //             variant: 'success',
    //             message:
    //                 'You have successfully assigned the bill.',
    //         });
    //         this.dispatchEvent(event);
    //         window.location.reload();
    //     }
    

        //Assign Users
        // handleAssign(){
        // console.log(this.recordUserId);
        // console.log(this.recordFOrUSerId)
        //     AssignBill({IdofOwner:this.recordFOrUSerId,Id:this.recordUserId}).then(()=>{
        //         const event = new ShowToastEvent({
        //             title: 'Successfully Assigned',
        //             variant: 'success',
                    
        //         });
        //         this.dispatchEvent(event);
        //         window.location.reload();


        //     }).catch(error => {
                
        //         this.error = error;
        //         console.log(this.error);
        //         const event = new ShowToastEvent({
        //             title: 'Error',
        //             variant: 'error',
        //             message:
        //                 'Please Try again',
        //         });
        //         this.dispatchEvent(event);
               

        //     });;
        // }

  
////////////////////////////////////////////////////////////////////////
//USERS DETECT//

@track showAdminView = false;
@track showUserView = false;
handleUser(){
                checkUsers({getProfile: 'System Administrator'}).then(profresult => {
                    if (profresult == true){
                    this.showAdminView = true;
                    this.showUserView = false;
                 
                    }
                });
                checkUsers({getProfile: 'Users Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = false;
                        this.showUserView = true;
                      
                    }
                });
                checkUsers({getProfile: 'Support Profile'}).then(profresult => {
                    if (profresult == true){
                    
                        this.showAdminView = true;
                        this.showUserView = false;
                   
                    }
                });
         }
/////////////////////////////////////////////////////////////////////////////c/billObject

    connectedCallback(){
        this.handleUser();

    }

}







   